const SUPABASE_URL = "https://zklsggugbqasamvpumgw.supabase.co";
const SUPABASE_KEY = "sb_publishable_rt6xbelrp6IJ5zvJfkoC5w_eeMqzG4G";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
        return new Response("WebSocket upgrade required", { status: 426 });
      }
      const token = url.searchParams.get("token");
      if (!token) return new Response("Missing login token", { status: 401 });

      // Validate the Supabase session before letting a client join the shared room.
      let user;
      try {
        const auth = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
          headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${token}`
          }
        });
        if (!auth.ok) return new Response("Invalid or expired login session", { status: 401 });
        user = await auth.json();
      } catch {
        return new Response("Authentication service unavailable", { status: 502 });
      }
      if (!user?.id) return new Response("Invalid login session", { status: 401 });

      const roomId = env.WORLD_ROOM.idFromName("my-virtual-world-main-room");
      const room = env.WORLD_ROOM.get(roomId);
      const headers = new Headers(request.headers);
      headers.set("X-World-User-Id", String(user.id));
      headers.set("X-World-Username", String(user.user_metadata?.username || user.email?.split("@")[0] || "لاعب").slice(0, 16));
      headers.delete("Authorization");
      const forwarded = new Request(request, { headers });
      return room.fetch(forwarded);
    }

    // All ordinary web requests go to the existing game files.
    return env.ASSETS.fetch(request);
  }
};

export class WorldRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.sockets = new Set();
    this.states = new Map();
  }

  async fetch(request) {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return new Response("WebSocket upgrade required", { status: 426 });
    }
    const live = [...this.sockets].filter(ws => ws.readyState === 1);
    if (live.length >= 50) return new Response("الغرفة ممتلئة (50 لاعب)", { status: 503 });

    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    const id = crypto.randomUUID();
    const uid = request.headers.get("X-World-User-Id") || "";
    const username = (request.headers.get("X-World-Username") || "لاعب").replace(/[<>\u0000-\u001f]/g, "").slice(0, 16);
    server.accept();
    server.serializeAttachment({ id, uid, username });
    this.sockets.add(server);

    // New arrival receives the current player snapshot.
    for (const [otherId, state] of this.states) {
      if (otherId !== id) this.safeSend(server, { ...state, id: otherId });
    }

    server.addEventListener("message", event => {
      if (typeof event.data !== "string" || event.data.length > 2048) return;
      let msg;
      try { msg = JSON.parse(event.data); } catch { return; }
      if (msg?.t !== "s") return;

      const attachment = server.deserializeAttachment() || { id, uid, username };
      const n = String(msg.n || attachment.username || "لاعب").replace(/[<>\u0000-\u001f]/g, "").slice(0, 16);
      const color = v => /^#[0-9a-fA-F]{3,8}$/.test(String(v || "")) ? String(v) : "#f1c27d";
      const num = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
      const state = {
        t: "s", id, uid: attachment.uid,
        x: Math.max(4, Math.min(796, num(msg.x, 380))),
        y: Math.max(60, Math.min(505, num(msg.y, 200))),
        n, skin: color(msg.skin), hair: color(msg.hair), shirt: color(msg.sh),
        hat: String(msg.hat || "").slice(0, 4),
        ch: Math.max(0, Math.min(3, num(msg.ch) | 0)),
        sit: (num(msg.sit, -1) >= 0 && num(msg.sit, -1) < 9) ? (num(msg.sit) | 0) : -1,
        say: String(msg.say || "").replace(/[<>\u0000-\u001f]/g, "").slice(0, 60),
        age: Math.max(0, Math.min(10000, num(msg.age)))
      };
      this.states.set(id, state);
      this.broadcast(state, server);
    });

    const cleanup = () => {
      this.sockets.delete(server);
      this.states.delete(id);
      this.broadcast({ t: "l", id });
    };
    server.addEventListener("close", cleanup);
    server.addEventListener("error", cleanup);
    return new Response(null, { status: 101, webSocket: client });
  }

  safeSend(ws, data) {
    try { if (ws.readyState === 1) ws.send(JSON.stringify(data)); } catch {}
  }

  broadcast(data, except = null) {
    for (const ws of this.sockets) {
      if (ws !== except) this.safeSend(ws, data);
    }
  }
}
