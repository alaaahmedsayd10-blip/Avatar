# My Virtual World v9 — Auth + Online

Arabic social-world prototype with the existing garden/beach map, avatar customization, seating, chat bubbles, pinch zoom, Supabase email/password authentication, and an authenticated WebSocket room capped at 50 concurrent connections.

## 1. Configure Supabase

1. Open the Supabase project matching the URL configured in `public/game.js`.
2. In **SQL Editor**, run `supabase_setup.sql` to create `public.players` and its row-level security policies.
3. In **Authentication → URL Configuration**, set the Site URL to your deployed website URL. Add your deployed URL to the allowed redirect URLs.
4. For production, keep email confirmation enabled. New users may need to click the confirmation link before they can log in.
5. The browser publishable key is intended for public clients; security depends on RLS and server-side authorization. Never put a Supabase `service_role` secret in browser code.

## 2. Run locally

Requires Node.js 18+.

```sh
npm install
npm start
```

Open `http://localhost:3000`. Register or log in with Supabase. WebSocket connections are accepted only when the access token is valid, and the server refuses new connections once 50 players are connected.

For deployment, set `SUPABASE_URL` and `SUPABASE_ANON_KEY` (or `SUPABASE_PUBLISHABLE_KEY`) as server environment variables when your host supports them. Use HTTPS/WSS in production.

## 3. Included

- Supabase email/password signup, login, session restore, and password reset email.
- Player profile upsert protected by row-level security (requires the SQL setup above).
- Server validates the Supabase access token before allowing multiplayer.
- A single shared WebSocket room, with a hard limit of 50 concurrent connections and existing-player snapshots for new arrivals.
- Movement/avatar state sync and simple chat bubbles using the current game's protocol.
- Pinch-to-zoom on touchscreens and wheel zoom on desktop.
- Existing map/assets and the current game systems are retained as the starting point.

## 4. Important limitations

This is a playable prototype, not a complete commercial-scale replica of Sanalika. It does not yet include private messaging, friend requests, moderation tools, a server-authoritative economy, payment processing, persistent inventories, or production monitoring. The current game currency and shop remain client-side prototype systems and must not be treated as secure or valuable. The server's 50-player cap is a connection cap for one shared room, not a load-tested guarantee of 50 smooth players on every hosting provider.
