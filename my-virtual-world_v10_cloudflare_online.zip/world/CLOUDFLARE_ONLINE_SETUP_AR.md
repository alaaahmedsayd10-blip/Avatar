# تفعيل الأونلاين على Cloudflare Workers

هذه النسخة تضيف غرفة مشتركة واحدة بحد أقصى 50 اتصالًا، وتستخدم Durable Objects وWebSockets بدل محاولة تشغيل `server.js` على Workers. تسجيل الحسابات يظل عبر Supabase كما هو.

## الملفات الجديدة
- `worker.js`: نقطة دخول Cloudflare Worker، تتحقق من جلسة Supabase، ثم تمرر الاتصال لغرفة Durable Object.
- `wrangler.toml`: إعداد ربط ملفات اللعبة وDurable Object.
- `public/game.js`: يفتح اتصال اللعبة على `/ws` ويرسل إحداثيات الشخصية ورسائل الفقاعات (الشات القريب).

## النشر
1. احتفظ بنسخة احتياطية من Worker الحالي.
2. افتح مشروعك في Cloudflare Workers. إذا كان المشروع مربوطًا بـ GitHub، ارفع محتويات مجلد `world` إلى المستودع المرتبط مع الاحتفاظ بملفات اللعبة الحالية.
3. انشر باستخدام Wrangler من مجلد `world`:
   ```sh
   npm install
   npx wrangler deploy
   ```
   (قد تحتاج تثبيت Wrangler: `npm install -D wrangler`.)
4. أول نشر ينشئ ترحيل Durable Object المعرّف في `wrangler.toml`. لو لوحة Cloudflare تعرض إعدادات Durable Objects يدويًا بدل Wrangler، أنشئ binding باسم `WORLD_ROOM` إلى class `WorldRoom` وأضف migration من نوع SQLite class باسم `WorldRoom`.
5. اختبر من نافذتين/جهازين مختلفين بحسابين مسجلين. بعد الدخول يجب أن يظهر اللاعبان ويتبادلا الحركة وفق الخريطة. إرسال رسالة في خانة الشات يحدّث فقاعة الكلام فوق الشخصية.

## ملاحظات مهمة
- `server.js` محفوظ لتشغيل النسخة محليًا، لكنه ليس الخادم الذي يشغّل WebSockets داخل Cloudflare Workers.
- لا تضع أي مفتاح Supabase service-role في المتصفح أو Worker. المفتاح العام الموجود مستخدم فقط مع `auth/v1/user` للتحقق من access token.
- الغرفة واحدة مشتركة؛ السقف 50 اتصالًا متزامنًا. هذه نسخة أولية ولم تُختبر باختبار تحميل 50 لاعبًا.
- إذا كان لدى مشروع Cloudflare إعداد أصول مختلف بالفعل، راجع `[assets]` في `wrangler.toml` قبل النشر حتى لا يتعارض مع إعداداته.
